import React, { useEffect } from 'react';
import AppNavigator from './src/screens/Navigator/AppNavigator';


export default function App() {

  return <AppNavigator />;
}
