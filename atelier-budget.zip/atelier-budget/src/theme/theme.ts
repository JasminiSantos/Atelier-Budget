import { DefaultTheme } from '@react-navigation/native';

export const theme = {
  colors: {
    appBg: '#FBF7FB',
    cardBg: '#FFFFFF',
    text: '#1C1C1E',
    muted: '#6B7280',
    primary: '#0B0B14',
    primaryFg: '#FFFFFF',
    accent: '#8B5CF6',
    inputBg: '#F3F4F6',
    border: '#E5E7EB',
    shadow: 'rgba(0,0,0,0.08)',
    tabBg: '#ECECF2',
  },
  radius: {
    xl: 24,
    lg: 14,
    md: 12,
    sm: 10,
    pill: 999,
  },
  navigation: DefaultTheme,
};
