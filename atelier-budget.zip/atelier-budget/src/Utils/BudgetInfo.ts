import { Material } from "../common/Material";
import { ProjectDetail } from "../common/ProjectDetail";
import { fmtBRL } from "./Currency";

export function buildBudgetMessage(
  project: ProjectDetail,
  materials: Material[],
  totals: { mat: number; labor: number; total: number; price: number }
) {
  const header = `Orçamento do projeto "${project.title}"\nCategoria: ${project.category}\n`;

  const resumo = [
    '',
    'Resumo:',
    `- Custo de materiais: ${fmtBRL(totals.mat)}`,
    `- Mão de obra: ${fmtBRL(totals.labor)}`,
    `- Preço sugerido: ${fmtBRL(totals.price)}`,
    `- Margem: ${(project.margin_percent * 100).toFixed(0)}%`,
    `- Horas: ${project.hours}h · Valor/hora: ${fmtBRL(project.hourly_rate)}`,
  ].join('\n');

  const materiaisTexto =
    materials.length === 0
      ? '\nMateriais: (nenhum cadastrado)'
      : '\nMateriais:\n' +
        materials
          .map(
            (m) =>
              `- ${m.name} · ${m.qty} ${m.unit} · ${fmtBRL(
                Number(m.unit_cost || 0)
              )}`
          )
          .join('\n');

  const notas = project.notes
    ? `\n\nObservações:\n${project.notes}`
    : '';

  return header + resumo + materiaisTexto + notas;
}
