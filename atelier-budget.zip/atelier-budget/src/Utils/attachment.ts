import { supabase } from '../lib/supabase/supabase';
import { Attachment } from '../common/Attachment';
import * as FileSystem from 'expo-file-system/legacy';
import { decode } from 'base64-arraybuffer';

const BUCKET = 'project-attachments';

export async function uploadAttachmentToStorage(
  userId: string,
  projectId: string,
  attachment: Attachment
): Promise<string> {
  const ext = attachment.name.split('.').pop() || 'dat';
  const path = `${userId}/${projectId}/${Date.now()}.${ext}`;

  console.log('Iniciando upload para', path, 'mime:', attachment.mimeType);

  const base64 = await FileSystem.readAsStringAsync(attachment.uri, {
    encoding: 'base64',
  });


  const arrayBuffer = decode(base64);

  const { data, error } = await supabase.storage
    .from(BUCKET)
    .upload(path, arrayBuffer, {
      upsert: true,
      contentType: attachment.mimeType || 'application/octet-stream',
    });

  if (error) {
    console.log('Erro Supabase Storage:', error);
    throw error;
  }

  console.log('Upload OK, data:', data);

  return data.path;
}


