import { MaterialRow } from "../common/MaterialRow";

export function fmtBRL(n: number) {
  const fixed = Number(n || 0).toFixed(2).replace('.', ',');
  return `R$ ${fixed}`;
}

export function parseNumBR(v: string): number {
  const n = parseFloat((v || '').replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
}

export function sanitizeMaterials(rows: MaterialRow[]) {
  return rows
    .map(r => ({
      ...r,
      name: (r.name || '').trim(),
      qty: String(parseNumBR(r.qty)),
      unitCost: String(parseNumBR(r.unitCost)),
      unit: (r.unit || 'un').trim(),
    }))
    .filter(r => r.name.length > 0);
}

export function getFileExt(name?: string | null) {
  if (!name) return 'bin';
  const i = name.lastIndexOf('.');
  if (i === -1) return 'bin';
  return name.slice(i + 1).toLowerCase();
}
