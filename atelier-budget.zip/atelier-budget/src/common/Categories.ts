export const CATEGORIES = [
  'Todas categorias', 'Crochê', 'Bordado', 'Beadwork', 'Costura',
  'Macramê', 'Papelaria', 'Marcenaria', 'Outro',
];