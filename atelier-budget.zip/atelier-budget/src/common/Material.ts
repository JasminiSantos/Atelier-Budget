export type Material = {
  id: string;
  project_id: string;
  name: string;
  qty: number;     
  unit: string;
  unit_cost: number;
};