export type MaterialRow = {
  id: string;
  name: string;
  qty: string;
  unit: string;
  unitCost: string;
};
