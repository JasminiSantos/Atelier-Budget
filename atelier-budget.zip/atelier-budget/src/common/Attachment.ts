export type Attachment = {
  uri: string;
  name: string;
  mimeType?: string | null;
};