export type Project = {
  id: string;
  title: string;
  category: string;
  file_path?: string | null;
  updated_at?: string | null;
  signedUrl?: string | null;
};