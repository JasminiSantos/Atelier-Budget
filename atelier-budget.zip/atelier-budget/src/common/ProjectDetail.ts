export type ProjectDetail = {
  id: string;
  title: string;
  category: string;
  margin_percent: number;
  hours: number;
  hourly_rate: number;
  notes?: string | null;
  file_path?: string | null;
  signedUrl?: string | null;
  share_token?: string | null;
};