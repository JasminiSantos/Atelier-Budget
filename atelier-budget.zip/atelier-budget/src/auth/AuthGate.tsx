// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { supabase } from '../lib/supabase/supabase';
import AuthScreen from '../screens/Views/Auth';
import HomeScreen from '../screens/Views/Home';
import ProjectFormScreen from '../screens/Views/ProjectForm';
import { RootStackParamList } from '../screens/Navigator/Types';
import { NavigationScreens } from '../screens/Navigator/NavigationScreens';
import { Pressable, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../theme/theme';
import ProjectDetailScreen from '../screens/Views/ProjectDetail';
import { getSession, signOut } from '../services/auth';

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AuthGate() {
  const [checking, setChecking] = useState(true);
  const [hasSession, setHasSession] = useState(false);

  useEffect(() => {
    getSession().then(({ data }) => {
      setHasSession(!!data.session);
      setChecking(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) =>
      setHasSession(!!s)
    );
    return () => sub.subscription.unsubscribe();
  }, []);

  if (checking) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName={hasSession ? 'Home' : 'Auth'}>
      {hasSession ? (
        <>
          <Stack.Screen 
          name={NavigationScreens.Home} 
          component={HomeScreen} 
          options={({ navigation }) => ({
              headerShown: true,
              headerTitle: '',
              headerShadowVisible: false,
              headerRight: () => (
                <Pressable
                  onPress={() => signOut()}
                  style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8 }}
                  accessibilityRole="button"
                  hitSlop={8}
                >
                  <Text style={{ marginRight: 6, fontWeight: '600', fontSize: 16, color: theme.colors.text }}>
                    Sair
                  </Text>
                </Pressable>
              ),
            })}
          />

          <Stack.Screen
            name={NavigationScreens.ProjectForm}
            component={ProjectFormScreen}
            options={({ navigation }) => ({
              headerShown: true,
              headerTitle: '',
              headerShadowVisible: false,
              headerLeft: () => (
                <Pressable
                  onPress={() => navigation.goBack()}
                  style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8 }}
                  accessibilityRole="button"
                  hitSlop={8}
                >
                  <Ionicons name="chevron-back" size={22} color={theme.colors.text} />
                  <Text style={{ marginLeft: 6, fontWeight: '600', fontSize: 16, color: theme.colors.text }}>
                    Voltar
                  </Text>
                </Pressable>
              ),
            })}
          />

          <Stack.Screen
            name={NavigationScreens.ProjectDetail}
            component={ProjectDetailScreen}
            options={({ navigation }) => ({
              headerShown: true,
              headerTitle: '',
              headerShadowVisible: false,
              headerLeft: () => (
                <Pressable
                  onPress={() => navigation.goBack()}
                  style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8 }}
                  accessibilityRole="button"
                  hitSlop={8}
                >
                  <Ionicons name="chevron-back" size={22} color={theme.colors.text} />
                  <Text style={{ marginLeft: 6, fontWeight: '600', fontSize: 16, color: theme.colors.text }}>
                    Voltar
                  </Text>
                </Pressable>
              ),
            })}
          />
        </>
      ) : (
        <>
          <Stack.Screen name={NavigationScreens.Auth}component={AuthScreen} 
          />
        </>
      )}
    </Stack.Navigator>
  );
}
