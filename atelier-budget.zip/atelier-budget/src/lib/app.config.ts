// app.config.ts
import 'dotenv/config'; // opcional, se quiser ler .env
import type { ExpoConfig } from '@expo/config';

const config: ExpoConfig = {
  name: 'Atelier Budget',
  slug: 'atelier-budget',
  scheme: 'atelierbudget',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  splash: { image: './assets/splash.png', resizeMode: 'contain', backgroundColor: '#FBF7FB' },
  ios: { supportsTablet: true, bundleIdentifier: 'com.seuorg.atelierbudget' },
  android: { package: 'com.seuorg.atelierbudget' },
  web: { bundler: 'metro' },

  extra: {
    EXPO_PUBLIC_SUPABASE_URL: process.env.EXPO_PUBLIC_SUPABASE_URL,
    EXPO_PUBLIC_SUPABASE_ANON_KEY: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY,
  },
};

export default config;
