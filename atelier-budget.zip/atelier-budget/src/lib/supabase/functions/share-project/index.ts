// @ts-nocheck
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false }
});

serve(async (req) => {
  try {
    const url = new URL(req.url);
    const parts = url.pathname.split("/").filter(Boolean);
    const token = parts[parts.length - 1];

    if (!token) {
      return new Response("Token inválido.", { status: 400 });
    }

    const { data, error } = await supabase.rpc("get_project_public", {
      p_token: token,
    });

    if (error) {
      console.error("Erro RPC:", error);
      return new Response("Erro ao carregar orçamento.", { status: 500 });
    }

    if (!data || !data.project) {
      return new Response("Orçamento não encontrado ou expirado.", {
        status: 404,
      });
    }

    const project = data.project as {
      title: string;
      category: string;
      notes: string | null;
      margin_percent: number;
      hours: number;
      hourly_rate: number;
    };

    const materials = (data.materials ?? []) as Array<{
      name: string;
      qty: number;
      unit: string;
      unit_cost: number;
    }>;

    const matTotal = materials.reduce(
      (sum, m) => sum + (Number(m.qty) || 0) * (Number(m.unit_cost) || 0),
      0
    );
    const labor =
      (Number(project.hours) || 0) * (Number(project.hourly_rate) || 0);
    const total = matTotal + labor;
    const price = total * (1 + (Number(project.margin_percent) || 0));

    const materiaisHtml =
      materials.length === 0
        ? `<p style="color:#6b7280;">Nenhum material cadastrado.</p>`
        : `
        <table style="width:100%; border-collapse:collapse; margin-top:8px;">
          <thead>
            <tr>
              <th style="text-align:left; padding:4px; border-bottom:1px solid #e5e7eb;">Nome</th>
              <th style="text-align:center; padding:4px; border-bottom:1px solid #e5e7eb;">Qtd</th>
              <th style="text-align:center; padding:4px; border-bottom:1px solid #e5e7eb;">Un</th>
              <th style="text-align:right; padding:4px; border-bottom:1px solid #e5e7eb;">R$</th>
            </tr>
          </thead>
          <tbody>
            ${materials
              .map(
                (m) => `
              <tr>
                <td style="padding:4px; border-bottom:1px solid #f3f4f6;">${m.name}</td>
                <td style="padding:4px; text-align:center; border-bottom:1px solid #f3f4f6;">${m.qty}</td>
                <td style="padding:4px; text-align:center; border-bottom:1px solid #f3f4f6;">${m.unit}</td>
                <td style="padding:4px; text-align:right; border-bottom:1px solid #f3f4f6;">${fmtBRL(
                  m.unit_cost
                )}</td>
              </tr>
            `
              )
              .join("")}
          </tbody>
        </table>
      `;

    const html = `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <title>Orçamento - ${project.title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
</head>
<body style="margin:0; font-family:-apple-system, BlinkMacSystemFont, system-ui, sans-serif; background:#f3f4f6;">
  <div style="max-width:640px; margin:0 auto; padding:16px;">
    <div style="background:#fff; border-radius:16px; padding:16px; box-shadow:0 10px 30px rgba(15,23,42,0.08);">
      <h1 style="margin:0 0 4px; font-size:20px;">${project.title}</h1>
      <p style="margin:0 0 12px; color:#6b7280;">Categoria: <strong>${project.category}</strong></p>

      <div style="margin-bottom:12px;">
        <h2 style="margin:0 0 8px; font-size:16px;">Resumo do orçamento</h2>
        <div style="border-radius:12px; border:1px solid #d1fae5; background:#ecfdf5; padding:12px;">
          <p style="margin:0 0 4px;">Custo Materiais: <strong>${fmtBRL(
            matTotal
          )}</strong></p>
          <p style="margin:0 0 4px;">Mão de Obra: <strong>${fmtBRL(
            labor
          )}</strong></p>
          <p style="margin:8px 0 0; border-top:1px solid #bbf7d0; padding-top:8px;">
            Preço sugerido: <strong style="font-size:18px;">${fmtBRL(
              price
            )}</strong>
          </p>
        </div>
        <p style="margin:8px 0 0; font-size:12px; color:#6b7280;">
          Margem: ${(project.margin_percent * 100).toFixed(0)}% &middot;
          Horas: ${project.hours}h &middot;
          Valor/hora: ${fmtBRL(project.hourly_rate)}
        </p>
      </div>

      <div style="margin-bottom:12px;">
        <h2 style="margin:0 0 8px; font-size:16px;">Materiais</h2>
        ${materiaisHtml}
      </div>

      ${
        project.notes
          ? `
        <div style="margin-top:12px;">
          <h2 style="margin:0 0 8px; font-size:16px;">Passos / Observações</h2>
          <p style="margin:0; white-space:pre-wrap; color:#374151;">${project.notes}</p>
        </div>
      `
          : ""
      }
    </div>

    <p style="margin:12px 0 0; text-align:center; font-size:12px; color:#9ca3af;">
      Orçamento gerado com Atelier Budget.
    </p>
  </div>
</body>
</html>`;

    return new Response(html, {
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  } catch (err) {
    console.error("Erro inesperado:", err);
    return new Response("Erro inesperado.", { status: 500 });
  }
});
