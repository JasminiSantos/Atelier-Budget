import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
export const BUCKET = 'project-attachments';
export const PUBLIC_BUDGET_BASE_URL ='https://systvnrhldnvibjdkhvw.supabase.co/functions/v1/orcamento-publico';

if (!SUPABASE_URL || !/^https:\/\/.+\.supabase\.co$/.test(SUPABASE_URL)) {
  throw new Error(
    `Supabase URL inválida/ausente. Recebido: "${SUPABASE_URL ?? 'undefined'}".
     Defina EXPO_PUBLIC_SUPABASE_URL em app.config.ts`
  );
}
if (!SUPABASE_ANON_KEY) {
  throw new Error(
    'Supabase anon key ausente. Defina EXPO_PUBLIC_SUPABASE_ANON_KEY em app.config.ts'
  );
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
