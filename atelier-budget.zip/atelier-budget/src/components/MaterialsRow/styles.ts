import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const s = StyleSheet.create({

  input: {
    backgroundColor: theme.colors.inputBg,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: theme.colors.border,
    color: theme.colors.text,
    height: 44,
  },

  // materiais (layout em bloco)
  matBlock: { marginBottom: 12 },
  full: { width: '100%', marginBottom: 10 },
  col: { flex: 1 },
  colWide: { flex: 1.4 },
  subLabel: { color: theme.colors.muted, fontSize: 12, marginBottom: 6 },

  // moeda grande
  moneyBig: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: 10,
    backgroundColor: theme.colors.inputBg,
    paddingHorizontal: 10,
    height: 44,
  },
  moneyPrefix: { fontWeight: '700', color: '#111827', marginRight: 6 },
  moneyInputBig: { flex: 1, color: theme.colors.text, fontSize: 16, paddingVertical: 0 },

  // lixeira branca com ícone vermelho
  trashWhite: {
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#FCA5A5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tCenter: { textAlign: 'center' as const },

  // adicionar material
  addRow: {
    marginTop: 6,
    alignSelf: 'flex-start',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: '#F3F4F6',
  },
  addRowText: { color: theme.colors.text, fontWeight: '600' }
});
