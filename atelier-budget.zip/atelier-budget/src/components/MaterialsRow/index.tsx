import {
  View,
  Text,
  TextInput,
  ScrollView,
  StyleSheet,
  Pressable,
  Image,
} from 'react-native';
import { nanoid } from 'nanoid/non-secure';
import { theme } from '../../theme/theme';
import { s} from './styles'
import { UNITS } from '../../common/Units';
import { MaterialRow } from '../../common/MaterialRow';
import MaterialIcons from '@expo/vector-icons/build/MaterialIcons';
import React from 'react';
import {Select} from './../Select/index'
import { Row } from '../Row';
import { Input } from '../../screens/Views/ProjectForm';

function makeRow(): MaterialRow {
  return { id: nanoid(), name: '', qty: '', unit: 'un', unitCost: '' };
}
export function MaterialsRow({
  row,
  onChange,
  onRemove,
}: {
  row: MaterialRow;
  onChange: (r: MaterialRow) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <View style={s.matBlock}>
      <Input
        style={s.full}
        placeholder="Ex: Miçanga"
        value={row.name}
        onChangeText={(t) => onChange({ ...row, name: t })}
      />

      <Row gap={10} align="center">
        <View style={s.col}>
          <Text style={s.subLabel}>Qtd</Text>
          <Input
            style={[s.input, s.tCenter]}
            placeholder="0"
            keyboardType="numeric"
            value={row.qty}
            onChangeText={(t) => onChange({ ...row, qty: t })}
          />
        </View>

        <View style={s.col}>
          <Text style={s.subLabel}>Un</Text>
          <Select
            value={row.unit}
            onChange={(v) => onChange({ ...row, unit: v })}
            items={UNITS}
          />
        </View>

        <View style={s.colWide}>
          <Text style={s.subLabel}>Valor/Un</Text>
        <View style={s.moneyBig}>
            <Text style={s.moneyPrefix}>R$</Text>
            <TextInput
              style={s.moneyInputBig}
              placeholder="0,00"
              keyboardType="numeric"
              value={row.unitCost}
              onChangeText={(t) => onChange({ ...row, unitCost: t })}
              placeholderTextColor={theme.colors.muted}
            />
          </View>
        </View>

        <Pressable
          onPress={() => onRemove(row.id)}
          style={s.trashWhite}
          accessibilityRole="button"
          accessibilityLabel="Excluir material"
        >
          <MaterialIcons name="delete-outline" size={20} color="#DC2626" />
        </Pressable>
      </Row>
    </View>
  );
}