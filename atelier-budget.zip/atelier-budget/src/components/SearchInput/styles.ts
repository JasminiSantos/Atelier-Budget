import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const styles = StyleSheet.create({
  box: { backgroundColor: theme.colors.cardBg, borderRadius: 10 },
  input: {
    backgroundColor: theme.colors.inputBg,
    borderRadius: 10,
    paddingHorizontal: 14, paddingVertical: 12,
    borderWidth: 1, borderColor: theme.colors.border,
    color: theme.colors.text,
  },
});
