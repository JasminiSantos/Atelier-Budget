import React from 'react';
import { View, TextInput, StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';
import { styles } from './styles';

type Props = { value: string; onChange: (v: string) => void; placeholder?: string };
export default function SearchInput({ value, onChange, placeholder }: Props) {
  return (
    <View style={styles.box}>
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder ?? 'Buscar...'}
        placeholderTextColor={theme.colors.muted}
        style={styles.input}
      />
    </View>
  );
}