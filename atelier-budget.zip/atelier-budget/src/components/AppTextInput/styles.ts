import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const styles = StyleSheet.create({
  wrap: { marginBottom: 12 },
  label: { color: theme.colors.text, fontWeight: '600', marginBottom: 6 },
  input: {
    backgroundColor: theme.colors.inputBg,
    borderRadius: theme.radius.sm,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: theme.colors.border,
    color: theme.colors.text,
  },
});
