import React from 'react';
import { TextInput, View, Text } from 'react-native';
import { theme } from '../../theme/theme';
import { styles } from './styles';

type KB =
  | 'default'
  | 'email-address'
  | 'numeric'
  | 'number-pad'
  | 'decimal-pad'
  | 'phone-pad'
  | 'url';

type Props = {
  label: string;
  placeholder?: string;
  value: string;
  onChangeText: (t: string) => void;
  secureTextEntry?: boolean;
  keyboardType?: KB;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
};

export default function AppTextInput({
  label,
  ...inputProps
}: Props) {
  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        {...inputProps}
        style={styles.input}
        placeholderTextColor={theme.colors.muted}
      />
    </View>
  );
}
