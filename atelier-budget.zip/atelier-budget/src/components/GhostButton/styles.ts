import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const styles = StyleSheet.create({
  btn: { paddingVertical: 8, paddingHorizontal: 10, borderRadius: 10 },
  txt: { color: theme.colors.muted, fontWeight: '600' },
});