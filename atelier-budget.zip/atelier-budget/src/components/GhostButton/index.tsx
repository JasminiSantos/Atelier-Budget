import React from 'react';
import { Pressable, Text } from 'react-native';
import {styles} from './styles'

type Props = { label: string; onPress: () => void };
export default function GhostButton({ label, onPress }: Props) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.btn, pressed && { opacity: 0.7 }]}>
      <Text style={styles.txt}>{label}</Text>
    </Pressable>
  );
}
