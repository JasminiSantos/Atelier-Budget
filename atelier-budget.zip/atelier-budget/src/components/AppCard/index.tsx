import React, { PropsWithChildren } from 'react';
import { View , ViewStyle, StyleProp} from 'react-native';
import { styles } from './styles';

type CardProps = PropsWithChildren<{ style?: StyleProp<ViewStyle> }>;

export default function AppCard({ children, style }: CardProps) {
  return <View style={[styles.card, style]}>{children}</View>;
}

