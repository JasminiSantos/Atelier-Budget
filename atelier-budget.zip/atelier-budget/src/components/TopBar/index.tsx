import React, { ReactNode } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import {styles} from './styles'

type Props = { left?: ReactNode; right?: ReactNode; title?: string };
export default function TopBar({ left, right, title = '' }: Props) {
  return (
    <View style={styles.wrap}>
      <View style={{ width: 64 }}>{left}</View>
      <Text style={styles.title}>{title}</Text>
      <View style={{ width: 64, alignItems: 'flex-end' }}>{right}</View>
    </View>
  );
}
