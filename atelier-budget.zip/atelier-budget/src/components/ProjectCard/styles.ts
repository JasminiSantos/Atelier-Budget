import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const styles = StyleSheet.create({
  card: {
    marginVertical: 8,
    borderRadius: 16,
    backgroundColor: '#fff',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },

  cover: {
    width: '100%',
    height: 140,
  },

  coverEmpty: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F3F4F6',
  },

  coverPlaceholder: {
    color: '#9CA3AF',
    fontSize: 13,
  },

  body: {
    paddingHorizontal: 14,
    paddingVertical: 10,
  },

  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  title: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
  },

  chip: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: '#EEF2FF',
    marginLeft: 8,
  },

  chipText: {
    fontSize: 11,
    fontWeight: '500',
    color: '#4F46E5',
  },

  updated: {
    marginTop: 4,
    fontSize: 11,
    color: '#9CA3AF',
  },
});
