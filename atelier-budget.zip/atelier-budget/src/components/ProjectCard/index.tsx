import React from 'react';
import { View, Text, Image, Pressable } from 'react-native';
import { Project } from '../../common/Project';
import { styles } from './styles';

type Props = {
  project: Project;
  onPress: () => void;
};

export function ProjectCard({ project, onPress }: Props) {
  return (
    <Pressable style={styles.card} onPress={onPress}>
      {project.signedUrl ? (
        <Image
          source={{ uri: project.signedUrl }}
          style={styles.cover}
          resizeMode="cover"
        />
      ) : (
        <View style={[styles.cover, styles.coverEmpty]}>
          <Text style={styles.coverPlaceholder}>Sem imagem</Text>
        </View>
      )}

      <View style={styles.body}>
        <View style={styles.topRow}>
          <Text numberOfLines={1} style={styles.title}>
            {project.title}
          </Text>

          <View style={styles.chip}>
            <Text style={styles.chipText}>{project.category}</Text>
          </View>
        </View>

        {project.updated_at && (
          <Text style={styles.updated}>
            Atualizado em{' '}
            {new Date(project.updated_at).toLocaleDateString('pt-BR')}
          </Text>
        )}
      </View>
    </Pressable>
  );
}
