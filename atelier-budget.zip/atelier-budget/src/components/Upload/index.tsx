import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  StyleSheet,
  Pressable,
  Image,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { theme } from '../../theme/theme';
import { s} from './styles'
import { Attachment } from '../../common/Attachment';

export function UploadPicker({
  attachment,
  onPick,
  onClear,
}: {
  attachment: Attachment | null;
  onPick: () => void;
  onClear: () => void;
}) {
  const isImage = attachment?.mimeType?.startsWith('image/');
  return (
    <View>
      {attachment ? (
        <View style={s.uploadChosen}>
          {isImage ? (
            <Image source={{ uri: attachment.uri }} style={s.preview} />
          ) : (
            <View style={s.previewPdf}>
              <MaterialIcons name="picture-as-pdf" size={28} color="#DC2626" />
            </View>
          )}
          <View style={{ flex: 1 }}>
            <Text style={s.fileName} numberOfLines={2}>{attachment.name}</Text>
            <Text style={s.fileMime}>{attachment.mimeType || 'arquivo'}</Text>
          </View>
          <Pressable onPress={onClear} style={s.clearBtn}>
            <MaterialIcons name="close" size={18} color={theme.colors.text} />
          </Pressable>
        </View>
      ) : (
        <Pressable onPress={onPick} style={s.uploadBox} accessibilityRole="button">
          <MaterialIcons name="upload-file" size={22} color={theme.colors.muted} />
          <Text style={[s.uploadText, { marginTop: 6 }]}>
            Toque para enviar JPG, PNG ou PDF (máx. 5 MB)
          </Text>
        </Pressable>
      )}
    </View>
  );
}