import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const s = StyleSheet.create({
  uploadBox: {
    height: 120,
    borderRadius: 12,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.inputBg,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  uploadText: { color: theme.colors.muted, textAlign: 'center', lineHeight: 20 },

  uploadChosen: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: 12,
    backgroundColor: theme.colors.inputBg,
    padding: 10,
  },
  preview: { width: 44, height: 44, borderRadius: 8 },
  previewPdf: {
    width: 44, height: 44, borderRadius: 8,
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#FEE2E2',
  },
  fileName: { color: theme.colors.text, fontWeight: '600' },
  fileMime: { color: theme.colors.muted, fontSize: 12, marginTop: 2 },
  clearBtn: {
    width: 32, height: 32, borderRadius: 16,
    borderWidth: 1, borderColor: theme.colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
});
