import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const styles = StyleSheet.create({
  wrap: {
    backgroundColor: theme.colors.tabBg,
    borderRadius: theme.radius.pill,
    padding: 4,
    flexDirection: 'row',
    gap: 6,
    marginBottom: 14,
  },
  tab: {
    flex: 1,
    borderRadius: theme.radius.pill,
    paddingVertical: 8,
    alignItems: 'center',
  },
  tabActive: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  tabText: { color: theme.colors.muted, fontWeight: '600' },
  tabTextActive: { color: theme.colors.text },
});
