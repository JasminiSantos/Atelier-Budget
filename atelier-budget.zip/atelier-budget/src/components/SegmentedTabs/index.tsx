import React from 'react';
import { View, Pressable, Text } from 'react-native';
import { styles } from './styles';

type Props = {
  items: string[];
  index: number;
  onChange: (i: number) => void;
};

export default function SegmentedTabs({ items, index, onChange }: Props) {
  return (
    <View style={styles.wrap} accessibilityRole="tablist">
      {items.map((label, i) => {
        const active = index === i;
        return (
          <Pressable
            key={`${label}-${i}`}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            onPress={() => onChange(i)}
            hitSlop={8}
            style={[styles.tab, active && styles.tabActive]}
          >
            <Text style={[styles.tabText, active && styles.tabTextActive]}>
              {label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
