import { View } from "react-native";
import { fmtBRL } from "../../Utils/Currency";
import {s} from './styles'
import { SumRow } from "../../screens/Views/ProjectForm";

export function BudgetSummary({
  mat,
  labor,
  price,
}: {
  mat: number;
  labor: number;
  price: number;
}) {
  return (
    <View style={s.sumBox}>
      <SumRow label="Custo Materiais:" value={fmtBRL(mat)} />
      <SumRow label="Mão de Obra:" value={fmtBRL(labor)} />
      <View style={s.sep} />
      <SumRow
        label="Preço Sugerido:"
        value={fmtBRL(price)}
        highlight
      />
    </View>
  );
}