import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const s = StyleSheet.create({
  sumBox: {
    backgroundColor: '#E8F8EE',
    borderRadius: 12,
    padding: 14,
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#C7F0D8',
  },
  sep: { height: 1, backgroundColor: '#B7E8CC', marginVertical: 6 },
});
