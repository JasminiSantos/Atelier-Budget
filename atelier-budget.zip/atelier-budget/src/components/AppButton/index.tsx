import React from 'react';
import { Pressable, Text, ActivityIndicator } from 'react-native';
import { theme } from '../../theme/theme';
import { styles } from './styles';

type Props = {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  testID?: string;
};

export default function AppButton({ title, onPress, disabled, loading, testID }: Props) {
  const isDisabled = disabled || loading;

  return (
    <Pressable
      accessibilityRole="button"
      testID={testID}
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.btn,
        pressed && { opacity: 0.9, transform: [{ scale: 0.996 }] },
        isDisabled && { opacity: 0.6 },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={theme.colors.primaryFg} />
      ) : (
        <Text style={styles.label}>{title}</Text>
      )}
    </Pressable>
  );
}
