import React, { ReactElement } from 'react';
import { View, Text } from 'react-native';
import AppButton from '../AppButton';
import { styles } from './styles';

type Props = {
  title: string;
  subtitle: string;
  ctaLabel: string;
  onPressCta: () => void;
  icon?: ReactElement | null;
};

export default function EmptyState({
  title, subtitle, ctaLabel, onPressCta, icon,
}: Props) {
  return (
    <View style={styles.wrap}>
      <View style={styles.iconWrap}>
        {icon ?? <View style={styles.iconPlaceholder} />}
      </View>

      <Text style={styles.title}>{title}</Text>
      <Text style={styles.sub}>{subtitle}</Text>

      <View style={{ height: 12 }} />
      <AppButton title={ctaLabel} onPress={onPressCta} />
    </View>
  );
}
