import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const styles = StyleSheet.create({
  wrap: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  iconWrap: { marginBottom: 8 },
  iconPlaceholder: { width: 56, height: 56, borderRadius: 28, backgroundColor: '#EEE' },
  title: { fontSize: 16, fontWeight: '700', color: theme.colors.text, marginBottom: 4 },
  sub: { color: theme.colors.muted, textAlign: 'center', paddingHorizontal: 24 },
});