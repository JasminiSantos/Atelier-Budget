import {
  View,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { theme } from '../../theme/theme'; 
import {s} from './style'

export function Select({
  value,
  onChange,
  items,
  placeholder,
  style,
}: {
  value: string;
  onChange: (v: string) => void;
  items: string[];
  placeholder?: string;
  style?: any;
}) {
  const hasValue = items.includes(value);
  const selectedValue = hasValue ? value : '';

  return (
    <View style={[s.selectBox, style]}>
      <Picker
        selectedValue={selectedValue}
        onValueChange={(v, idx) => {
          if (v === '') return;
          onChange(String(v));
        }}
        mode="dropdown"
        dropdownIconColor={theme.colors.muted}
        style={s.pickerText}
      >
        {(!hasValue && placeholder) ? (
          <Picker.Item label={placeholder} value="" />
        ) : null}
        {items.map(opt => (
          <Picker.Item key={opt} label={opt} value={opt} />
        ))}
      </Picker>
    </View>
  );
}