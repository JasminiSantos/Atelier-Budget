import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const s = StyleSheet.create({
  selectBox: {
    height: 44,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.inputBg,
    justifyContent: 'center',
    paddingHorizontal: 6,
  },
  pickerText: { color: theme.colors.text },
});

