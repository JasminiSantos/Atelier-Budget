import { View } from "react-native";

export function Row({
  children,
  align = 'flex-start',
  justify = 'flex-start',
  gap = 8,
  style,
}: React.PropsWithChildren & {
  align?: 'flex-start' | 'center' | 'flex-end';
  justify?: 'flex-start' | 'space-between' | 'center' | 'flex-end';
  gap?: number;
  style?: any;
}) {
  return (
    <View
      style={[
        { flexDirection: 'row', alignItems: align, justifyContent: justify, gap },
        style,
      ]}
    >
      {children}
    </View>
  );
}