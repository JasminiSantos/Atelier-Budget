import { StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';

export const styles = StyleSheet.create({
  trigger: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: theme.colors.inputBg, borderRadius: 10,
    paddingHorizontal: 14, paddingVertical: 12, borderWidth: 1, borderColor: theme.colors.border,
  },
  triggerTxt: { color: theme.colors.text, fontWeight: '600' },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.2)' },
  sheet: {
    position: 'absolute', left: 16, right: 16, top: 120,
    backgroundColor: theme.colors.cardBg, borderRadius: 12,
    borderWidth: 1, borderColor: theme.colors.border, maxHeight: 360, overflow: 'hidden',
  },
  item: { paddingHorizontal: 16, paddingVertical: 14 },
  itemTxt: { color: theme.colors.text },
});