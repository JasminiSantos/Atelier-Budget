import React, { useState } from 'react';
import { View, Pressable, Text, Modal, FlatList, StyleSheet } from 'react-native';
import { theme } from '../../theme/theme';
import { styles } from './styles';

type Props = { value: string; onChange: (v: string) => void; items: string[] };

export default function CategoryFilter({ value, onChange, items }: Props) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Pressable style={styles.trigger} onPress={() => setOpen(true)}>
        <Text style={styles.triggerTxt}>{value}</Text>
        <Text style={{ color: theme.colors.muted, marginLeft: 8 }}>▾</Text>
      </Pressable>

      <Modal transparent visible={open} animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.backdrop} onPress={() => setOpen(false)} />
        <View style={styles.sheet}>
          <FlatList
            data={items}
            keyExtractor={(it) => it}
            renderItem={({ item }) => (
              <Pressable
                style={styles.item}
                onPress={() => { onChange(item); setOpen(false); }}
              >
                <Text style={styles.itemTxt}>{item}</Text>
              </Pressable>
            )}
          />
        </View>
      </Modal>
    </>
  );
}
