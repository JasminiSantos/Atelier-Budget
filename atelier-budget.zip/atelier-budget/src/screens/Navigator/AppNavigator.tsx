import AuthScreen from "../Views/Auth";
import HomeScreen from "../Views/Home";
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { NavigationScreens } from "./NavigationScreens";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { StatusBar } from "react-native";
import AuthGate from "../../auth/AuthGate";

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (

    <NavigationContainer>
        <AuthGate />
    </NavigationContainer>

  );
}