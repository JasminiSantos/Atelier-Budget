export type RootStackParamList = {
  Auth: undefined;
  Home: undefined;
  ProjectForm: { projectId?: string } | undefined;
};
