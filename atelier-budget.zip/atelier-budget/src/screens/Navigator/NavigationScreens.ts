export enum NavigationScreens {
  Auth = 'Auth',
  Home = 'Home',
  ProjectForm = "ProjectForm",
  ProjectDetail = "ProjectDetail"
}