import { StyleSheet } from 'react-native';
import { theme } from '../../../theme/theme'

export const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.colors.appBg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.colors.appBg },
  muted: { color: theme.colors.muted },
  error: { color: '#B91C1C', fontWeight: '600' },

  header: {
    flexDirection: 'row', alignItems: 'center',
    height: 56, paddingHorizontal: 12, backgroundColor: '#fff',
    borderBottomColor: '#eee', borderBottomWidth: 1,
  },
  back: { fontSize: 24, paddingRight: 8, color: theme.colors.text },
  headerTitle: { fontSize: 16, fontWeight: '600', color: theme.colors.text },

  top: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8, gap: 8 },
  title: { fontSize: 22, fontWeight: '700', color: theme.colors.text },
  actions: { flexDirection: 'row', gap: 8 },

  chip: {
    alignSelf: 'flex-start',
    backgroundColor: '#0F172A', paddingHorizontal: 10, paddingVertical: 6,
    borderRadius: 999,
  },
  chipText: { color: '#fff', fontWeight: '600' },

  cover: { width: '100%', height: 240, borderRadius: 12 },
  coverEmpty: {
    alignItems: 'center', justifyContent: 'center', backgroundColor: theme.colors.inputBg,
    borderWidth: 1, borderColor: theme.colors.border,
  },

  budgetHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  budgetIcon: { fontSize: 18, color: '#059669', marginRight: 6 },
  cardTitle: { fontSize: 16, fontWeight: '700', color: theme.colors.text },

  budgetGrid: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10, marginTop: 6 },
  gridCell: { flex: 1 },
  gridLabel: { color: theme.colors.muted, marginBottom: 4 },
  gridValue: { color: theme.colors.text, fontWeight: '700' },

  sumBox: {
    backgroundColor: '#E8F8EE', borderRadius: 12, padding: 12,
    borderWidth: 1, borderColor: '#C7F0D8',
  },
  sumRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  sumLabel: { color: '#374151', fontWeight: '600' },
  sumValue: { color: '#111827', fontWeight: '700' },
  sumHL: { color: '#047857' },
  sep: { height: 1, backgroundColor: '#B7E8CC', marginVertical: 6 },

  matHeader: { flexDirection: 'row', gap: 8, marginTop: 4, marginBottom: 6 },
  th: { color: '#6B7280', fontWeight: '600' },
  td: { color: theme.colors.text },
  matRow: { flexDirection: 'row', gap: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  flex1: { flex: 1 }, flex2: { flex: 2 },
  tCenter: { textAlign: 'center' as const },
  tRight: { textAlign: 'right' as const },
  notes: { marginTop: 8, color: theme.colors.text, lineHeight: 20 },

  pill: {
    paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1,
  },
  pillNeutral: { borderColor: theme.colors.border, backgroundColor: '#fff' },
  pillDanger: { borderColor: '#EF4444', backgroundColor: '#EF4444' },
  pillText: { fontWeight: '600', color: theme.colors.text },
});