// src/screens/ProjectDetail/index.tsx
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  RefreshControl,
  Alert,
  Share,
  Pressable,
} from 'react-native';
import { useFocusEffect, useRoute } from '@react-navigation/native';
import { BUCKET, PUBLIC_BUDGET_BASE_URL, supabase } from '../../../lib/supabase/supabase';
import AppCard from '../../../components/AppCard';
import AppButton from '../../../components/AppButton';
import { styles } from './styles';
import { ProjectDetail } from '../../../common/ProjectDetail';
import { Material } from '../../../common/Material';
import { NavigationScreens } from '../../Navigator/NavigationScreens';
import { SumRow } from '../ProjectForm';
import { Feather } from '@expo/vector-icons';
import { buildBudgetMessage } from '../../../Utils/BudgetInfo';

type RouteParams = { projectId: string };

export default function ProjectDetailScreen({ navigation }: { navigation: any }) {
  const route = useRoute();
  const { projectId } = (route.params as RouteParams) ?? { projectId: '' };

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [project, setProject] = useState<ProjectDetail | null>(null);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setError(null);
    try {
        const { data: proj, error: e1 } = await supabase
        .from('projects')
        .select(
            'id, title, category, margin_percent, hours, hourly_rate, notes, file_path, share_token'
        )
        .eq('id', projectId)
        .single();


      if (e1) throw e1;

      let signedUrl: string | null = null;
      if (proj.file_path) {
        const { data: urlData, error: urlErr } = await supabase.storage
          .from(BUCKET)
          .createSignedUrl(proj.file_path, 60 * 60);

        if (urlErr) {
          console.log('Erro ao criar signed URL:', urlErr);
        } else {
          signedUrl = urlData?.signedUrl ?? null;
        }
      }

      const { data: mats, error: e2 } = await supabase
        .from('materials')
        .select('*')
        .eq('project_id', projectId)
        .order('name', { ascending: true });

      if (e2) throw e2;

      setProject({ ...(proj as any), signedUrl } as ProjectDetail);
      setMaterials((mats ?? []) as Material[]);
    } catch (e: any) {
      console.log('Erro ao carregar projeto:', e);
      setError(e?.message ?? 'Falha ao carregar projeto.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [projectId]);

    const handleShareBudget = async () => {
    if (!project) return;

    try {
        let token = project.share_token;

        if (!token) {
        const { data, error } = await supabase.rpc('generate_share_token', {
            p_project_id: projectId,
        });

        if (error) {
            throw error;
        }

        token = data as string;
        setProject(prev =>
            prev ? { ...prev, share_token: token ?? null } : prev
        );
        }

        if (!token) {
        throw new Error('Não foi possível gerar o token de compartilhamento.');
        }
        const url = `${PUBLIC_BUDGET_BASE_URL}/${token}`;

        await Share.share({
        message: `Orçamento do projeto "${project.title}":\n${url}`,
        });

    } catch (e: any) {
        console.log('Erro ao compartilhar orçamento:', e);
        Alert.alert(
        'Erro',
        e?.message || 'Não foi possível gerar o link de compartilhamento.'
        );
    }
    };

    const handleSharePlain = async () => {
    if (!project) return;

    try {
        const message = buildBudgetMessage(project, materials, totals);

        await Share.share({
        message,
        });
    } catch (e: any) {
        console.log('Erro ao compartilhar orçamento simples:', e);
        Alert.alert(
        'Erro',
        e?.message || 'Não foi possível compartilhar o orçamento.'
        );
    }
    };



    const handleRevokeShare = async () => {
    if (!project) return;

    try {
        const { error } = await supabase.rpc('revoke_share_token', {
        p_project_id: projectId,
        });

        if (error) throw error;

        setProject(prev => (prev ? { ...prev, share_token: null } : prev));
        Alert.alert('Pronto', 'Compartilhamento revogado.');
    } catch (e: any) {
        console.log('Erro ao revogar compartilhamento:', e);
        Alert.alert(
        'Erro',
        e?.message || 'Não foi possível revogar o compartilhamento.'
        );
    }
    };


    useFocusEffect(
        useCallback(() => {
        fetchData();
        }, [fetchData])
    );

  const onRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  const totals = useMemo(() => {
    const mat = materials.reduce(
      (sum, m) => sum + (Number(m.qty) || 0) * (Number(m.unit_cost) || 0),
      0
    );
    const labor =
      (Number(project?.hours) || 0) * (Number(project?.hourly_rate) || 0);
    const total = mat + labor;
    const margin = Number(project?.margin_percent) || 0;
    const price = total * (1 + margin);
    return { mat, labor, total, price };
  }, [materials, project]);

  function fmtBRL(n: number) {
    return `R$ ${Number(n || 0).toFixed(2).replace('.', ',')}`;
  }

  const handleEdit = () => {
    navigation.navigate(NavigationScreens.ProjectForm, { projectId });
  };

  const handleDelete = () => {
    Alert.alert('Excluir projeto', 'Tem certeza que deseja excluir este projeto?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: async () => {
          const { error: e } = await supabase
            .from('projects')
            .delete()
            .eq('id', projectId);
          if (e) {
            Alert.alert('Erro', e.message);
            return;
          }
          navigation.goBack();
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <Text style={styles.muted}>Carregando…</Text>
      </View>
    );
  }

  if (error || !project) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{error ?? 'Projeto não encontrado.'}</Text>
        <View style={{ height: 12 }} />
        <AppButton title="Tentar novamente" onPress={fetchData} />
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={{ padding: 16, paddingBottom: 32 }}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <View style={styles.top}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 12,
          }}
        >
          <Text style={styles.title} numberOfLines={2}>
            {project.title}
          </Text>

        <View style={{ flexDirection: 'row', gap: 8 }}>
        <ActionPill
            label="Compartilhar orçamento"
            icon="share-2"
            onPress={handleSharePlain}
            variant="neutral"
        />

        {/* {project.share_token && (
            <ActionPill
            label="Revogar link de compartilhamento"
            icon="slash"
            onPress={handleRevokeShare}
            variant="danger"
            />
        )} */}

        <ActionPill
            label="Editar projeto"
            icon="edit-2"
            onPress={handleEdit}
            variant="neutral"
        />

        <ActionPill
            label="Excluir projeto"
            icon="trash-2"
            onPress={handleDelete}
            variant="danger"
        />
        </View>
        </View>

        <CategoryChip text={project.category} />
      </View>

      <AppCard style={{ marginBottom: 16 }}>
        {project.signedUrl ? (
          <Image
            source={{ uri: project.signedUrl }}
            resizeMode="cover"
            style={styles.cover}
          />
        ) : (
          <View style={[styles.cover, styles.coverEmpty]}>
            <Text style={styles.muted}>Sem anexo</Text>
          </View>
        )}
      </AppCard>

      <AppCard style={{ marginBottom: 16 }}>
        <View style={styles.budgetHead}>
          <Text style={styles.budgetIcon}>$</Text>
          <Text style={styles.cardTitle}>Orçamento</Text>
        </View>

        <View style={styles.budgetGrid}>
          <GridCell
            label="Margem"
            value={`${Math.round((project.margin_percent || 0) * 100)}%`}
          />
          <GridCell label="Horas" value={`${project.hours}h`} />
          <GridCell label="Valor/Hora" value={fmtBRL(project.hourly_rate)} />
        </View>

        <View style={styles.sumBox}>
          <SumRow label="Custo Materiais:" value={fmtBRL(totals.mat)} />
          <SumRow label="Mão de Obra:" value={fmtBRL(totals.labor)} />
          <View style={styles.sep} />
          <SumRow
            label="Preço Sugerido:"
            value={fmtBRL(totals.price)}
            highlight
          />
        </View>
      </AppCard>

      <AppCard style={{ marginBottom: 16 }}>
        <Text style={styles.cardTitle}>Materiais</Text>
        {materials.length === 0 ? (
          <Text style={styles.muted}>Nenhum material cadastrado.</Text>
        ) : (
          <View style={{ marginTop: 8 }}>
            <View style={styles.matHeader}>
              <Text style={[styles.th, styles.flex2]}>Nome</Text>
              <Text style={[styles.th, styles.flex1, styles.tCenter]}>Qtd</Text>
              <Text style={[styles.th, styles.flex1, styles.tCenter]}>Un</Text>
              <Text style={[styles.th, styles.flex1, styles.tRight]}>R$</Text>
            </View>
            {materials.map((m) => (
              <View key={m.id} style={styles.matRow}>
                <Text
                  style={[styles.td, styles.flex2]}
                  numberOfLines={1}
                >
                  {m.name}
                </Text>
                <Text style={[styles.td, styles.flex1, styles.tCenter]}>
                  {m.qty}
                </Text>
                <Text style={[styles.td, styles.flex1, styles.tCenter]}>
                  {m.unit}
                </Text>
                <Text style={[styles.td, styles.flex1, styles.tRight]}>
                  {fmtBRL(m.unit_cost)}
                </Text>
              </View>
            ))}
          </View>
        )}
      </AppCard>

      {!!project.notes && (
        <AppCard>
          <Text style={styles.cardTitle}>Passos/Observações</Text>
          <Text style={styles.notes}>{project.notes}</Text>
        </AppCard>
      )}
    </ScrollView>
  );
}

function CategoryChip({ text }: { text: string }) {
  return (
    <View style={styles.chip}>
      <Text style={styles.chipText}>{text}</Text>
    </View>
  );
}

function ActionPill({
  label,
  onPress,
  variant = 'neutral',
  icon,
}: {
  label: string;
  onPress: () => void;
  variant?: 'neutral' | 'danger';
  icon: React.ComponentProps<typeof Feather>['name'];
}) {
  const isDanger = variant === 'danger';

  return (
    <Pressable
      onPress={onPress}
      hitSlop={8}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={[
        styles.pill,
        styles.pillNeutral,
        {
          width: 40,
          height: 40,
          borderRadius: 18,
          alignItems: 'center',
          justifyContent: 'center',
          paddingHorizontal: 0,
        },
      ]}
    >
      <Feather
        name={icon}
        size={18}
        color={isDanger ? '#B91C1C' : '#111827'}
      />
    </Pressable>
  );
}


function GridCell({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.gridCell}>
      <Text style={styles.gridLabel}>{label}</Text>
      <Text style={styles.gridValue}>{value}</Text>
    </View>
  );
}
