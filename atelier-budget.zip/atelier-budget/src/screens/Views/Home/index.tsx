import React, { useState, useCallback } from 'react';
import { View, FlatList, ActivityIndicator, Text, Image, Pressable } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { styles } from './styles';
import TopBar from '../../../components/TopBar';
import SearchInput from '../../../components/SearchInput';
import CategoryFilter from '../../../components/CategoryFilter';
import GhostButton from '../../../components/GhostButton';
import AppButton from '../../../components/AppButton';
import EmptyState from '../../../components/EmptyState';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { CATEGORIES } from '../../../common/Categories';
import { supabase } from '../../../lib/supabase/supabase';
import { Project } from '../../../common/Project';
import { ProjectCard } from '../../../components/ProjectCard';
import { NavigationScreens } from '../../Navigator/NavigationScreens';

const BUCKET = 'project-attachments';

export default function HomeScreen({ navigation }: { navigation: any }) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(false);

  const loadProjects = useCallback(async () => {
    setLoading(true);
    try {
      const { data: userData, error: userErr } = await supabase.auth.getUser();
      if (userErr || !userData?.user?.id) {
        setProjects([]);
        return;
      }

      const userId = userData.user.id;

      const { data, error } = await supabase
        .from('projects')
        .select('id, title, category, file_path, updated_at')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false });

      if (error) {
        console.warn('Erro ao carregar projetos', error);
        setProjects([]);
        return;
      }

      const baseProjects = data || [];

      const withUrls = await Promise.all(
        baseProjects.map(async (p) => {
          if (!p.file_path) return p;

          const { data: urlData, error: urlErr } = await supabase.storage
            .from(BUCKET)
            .createSignedUrl(p.file_path, 60 * 60);

          if (urlErr) {
            console.warn('Erro ao criar signedUrl p/ projeto', p.id, urlErr);
            return p;
          }

          return {
            ...p,
            signedUrl: urlData?.signedUrl ?? null,
          };
        })
      );

      setProjects(withUrls as Project[]);

      } finally {
        setLoading(false);
      }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadProjects();
    }, [loadProjects])
  );

  const filtered = projects.filter(p => {
    const okText = p.title.toLowerCase().includes(query.toLowerCase());
    const okCat = category === CATEGORIES[0] || p.category === category;
    return okText && okCat;
  });

  return (
    <View style={styles.root}>

      <View style={styles.controls}>
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar projetos..." />
        <View style={{ height: 8 }} />
        <View style={styles.row}>
          <CategoryFilter value={category} onChange={setCategory} items={CATEGORIES} />
          <View style={{ width: 12 }} />
          <AppButton
            title="+  Novo Projeto"
            onPress={() => navigation.navigate(NavigationScreens.ProjectForm)}
          />
        </View>
      </View>

      {loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator />
        </View>
      ) : filtered.length === 0 ? (
        <EmptyState
          title="Nenhum projeto"
          subtitle="Crie seu primeiro projeto para começar"
          ctaLabel="+ Criar Projeto"
          onPressCta={() => navigation.navigate(NavigationScreens.ProjectForm)}
          icon={<MaterialCommunityIcons name="archive" size={48} color="#8B5CF6" />}
        />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
          renderItem={({ item }) => (
            <ProjectCard
              project={item}
              onPress={() => {
                navigation.navigate(NavigationScreens.ProjectDetail, {
                  projectId: item.id,
                });
              }}
            />
          )}
        />
      )}
    </View>
  );
}
