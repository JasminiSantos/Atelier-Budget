import { StyleSheet } from 'react-native';
import { theme } from '../../../theme/theme'

export const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.colors.appBg },
  controls: { padding: 16, borderBottomWidth: 1, borderBottomColor: theme.colors.border },
  row: { flexDirection: 'row', alignItems: 'center' },
});
