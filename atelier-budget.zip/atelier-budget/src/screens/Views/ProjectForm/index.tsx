import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  Pressable,
  Alert,
} from 'react-native';
import { nanoid } from 'nanoid/non-secure';
import * as DocumentPicker from 'expo-document-picker';
import { theme } from '../../../theme/theme';
import { s } from './styles';
import { CATEGORIES } from '../../../common/Categories';
import { fmtBRL, parseNumBR, sanitizeMaterials } from '../../../Utils/Currency';
import { supabase } from '../../../lib/supabase/supabase';
import { Attachment } from '../../../common/Attachment';
import { MaterialRow } from '../../../common/MaterialRow';
import { uploadAttachmentToStorage } from '../../../Utils/attachment';
import { UploadPicker } from '../../../components/Upload';
import { Select } from '../../../components/Select';
import { MaterialsRow } from '../../../components/MaterialsRow';
import { BudgetSummary } from '../../../components/BudgetSummary';
import { Row } from '../../../components/Row';

type RouteParams = { projectId?: string };

export default function ProjectFormScreen({
  navigation,
  route,
}: {
  navigation: any;
  route: any;
}) {
  const { projectId } = (route.params as RouteParams) ?? {};
  const isEditing = !!projectId;

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<string>('Crochê');
  const [refUrl, setRefUrl] = useState('');
  const [margin, setMargin] = useState('30'); // em %
  const [hours, setHours] = useState('0');
  const [hourRate, setHourRate] = useState('0');
  const [notes, setNotes] = useState('');
  const [attachment, setAttachment] = useState<Attachment | null>(null);

  const [existingFilePath, setExistingFilePath] = useState<string | null>(null);

  const [materials, setMaterials] = useState<MaterialRow[]>([makeRow()]);
  const [loading, setLoading] = useState(false);
  const [prefilling, setPrefilling] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  const canSave =
    title.trim().length > 0 &&
    CATEGORIES.includes(category) &&
    sanitizeMaterials(materials).length > 0 &&
    !loading &&
    !prefilling;

  useEffect(() => {
    if (!projectId) return;

    async function loadForEdit() {
      try {
        setPrefilling(true);
        setErrorText(null);

        const { data: proj, error: projErr } = await supabase
          .from('projects')
          .select(
            'id, title, category, ref_url, margin_percent, hours, hourly_rate, notes, file_path'
          )
          .eq('id', projectId)
          .single();

        if (projErr || !proj) {
          throw projErr || new Error('Projeto não encontrado');
        }

        setTitle(proj.title ?? '');
        setCategory(proj.category ?? 'Crochê');
        setRefUrl(proj.ref_url ?? '');
        const marginPct = (proj.margin_percent ?? 0) * 100;
        setMargin(String(Math.round(marginPct)));
        setHours(String(proj.hours ?? 0));
        setHourRate(String(proj.hourly_rate ?? 0));
        setNotes(proj.notes ?? '');
        setExistingFilePath(proj.file_path ?? null);

        const { data: mats, error: matsErr } = await supabase
          .from('materials')
          .select('id, name, qty, unit, unit_cost')
          .eq('project_id', projectId)
          .order('name', { ascending: true });

        if (matsErr) throw matsErr;

        const rows: MaterialRow[] =
          (mats ?? []).map((m: any) => ({
            id: m.id,
            name: m.name ?? '',
            qty: String(m.qty ?? ''),
            unit: m.unit ?? 'un',
            unitCost: String(m.unit_cost ?? ''),
          })) || [];

        setMaterials(rows.length > 0 ? rows : [makeRow()]);
      } catch (e: any) {
        console.log('Erro ao carregar para edição:', e);
        setErrorText(e?.message || 'Erro ao carregar projeto para edição.');
      } finally {
        setPrefilling(false);
      }
    }

    loadForEdit();
  }, [projectId]);

  function addMaterialRow() {
    setMaterials((prev) => [...prev, makeRow()]);
  }
  function updateRow(next: MaterialRow) {
    setMaterials((prev) => prev.map((r) => (r.id === next.id ? next : r)));
  }
  function removeRow(id: string) {
    setMaterials((prev) => prev.filter((r) => r.id !== id));
  }

  const totals = useMemo(() => {
    const mat = materials.reduce((acc, r) => {
      const q = parseFloat(r.qty.replace(',', '.')) || 0;
      const c = parseFloat(r.unitCost.replace(',', '.')) || 0;
      return acc + q * c;
    }, 0);
    const h = parseFloat(hours.replace(',', '.')) || 0;
    const rate = parseFloat(hourRate.replace(',', '.')) || 0;
    const labor = h * rate;
    const m = (parseFloat(margin.replace(',', '.')) || 0) / 100;
    const total = mat + labor;
    const price = total * (1 + m);
    return { mat, labor, total, price };
  }, [materials, hours, hourRate, margin]);

  async function pickAttachment() {
    const res = await DocumentPicker.getDocumentAsync({
      type: ['image/*', 'application/pdf'],
      multiple: false,
      copyToCacheDirectory: true,
    });
    if (res.canceled || !res.assets?.[0]) return;
    const file = res.assets[0];
    setAttachment({
      uri: file.uri,
      name: file.name ?? 'arquivo',
      mimeType: file.mimeType,
    });
  }

  async function onSubmit() {
    if (loading || prefilling) return;
    setLoading(true);
    setErrorText(null);

    try {
      const { data: userData, error: userErr } = await supabase.auth.getUser();
      if (userErr || !userData?.user?.id) {
        throw new Error('Você precisa estar logado para salvar o projeto.');
      }
      const userId = userData.user.id;

      const titleTrim = title.trim();
      if (!titleTrim) throw new Error('Informe um título para o projeto.');
      if (!CATEGORIES.includes(category))
        throw new Error('Selecione uma categoria válida.');

      const cleanMaterials = sanitizeMaterials(materials);
      if (cleanMaterials.length === 0) {
        throw new Error('Adicione pelo menos um material com nome.');
      }

      const marginNum = parseNumBR(margin);
      const hoursNum = parseNumBR(hours);
      const hourRateNum = parseNumBR(hourRate);

      let currentProjectId = projectId;

      if (isEditing && currentProjectId) {
        const { error: projErr } = await supabase
          .from('projects')
          .update({
            title: titleTrim,
            category,
            ref_url: refUrl || null,
            margin_percent: marginNum / 100,
            hours: hoursNum,
            hourly_rate: hourRateNum,
            notes: notes || null,
          })
          .eq('id', currentProjectId);

        if (projErr) {
          throw projErr;
        }

        await supabase.from('materials').delete().eq('project_id', currentProjectId);
      } else {
        const { data: proj, error: projErr } = await supabase
          .from('projects')
          .insert([
            {
              user_id: userId,
              title: titleTrim,
              category,
              ref_url: refUrl || null,
              margin_percent: marginNum / 100,
              hours: hoursNum,
              hourly_rate: hourRateNum,
              notes: notes || null,
            },
          ])
          .select('id')
          .single();

        if (projErr || !proj?.id) {
          throw new Error(projErr?.message || 'Não foi possível criar o projeto.');
        }
        currentProjectId = proj.id as string;
      }

      if (!currentProjectId) {
        throw new Error('ID do projeto não encontrado.');
      }

      if (attachment) {
        try {
          const attachmentPath = await uploadAttachmentToStorage(
            userId,
            currentProjectId,
            attachment
          );

          const { error: upErr } = await supabase
            .from('projects')
            .update({ file_path: attachmentPath })
            .eq('id', currentProjectId);

          if (upErr) throw upErr;
        } catch (up) {
          console.warn('Falha ao enviar anexo:', up);
          Alert.alert(
            'Aviso',
            'Não foi possível enviar o arquivo anexo. O projeto foi salvo sem atualizar o arquivo.'
          );
        }
      } else if (!isEditing) {
      }
      const materialRows = cleanMaterials.map((m) => ({
        project_id: currentProjectId,
        name: m.name,
        qty: parseNumBR(m.qty),
        unit: m.unit,
        unit_cost: parseNumBR(m.unitCost),
      }));

      const { error: matErr } = await supabase
        .from('materials')
        .insert(materialRows);

      if (matErr) {
        throw new Error('Erro ao salvar materiais: ' + matErr.message);
      }

      Alert.alert(
        'Sucesso',
        isEditing ? 'Projeto atualizado com sucesso!' : 'Projeto salvo com sucesso!',
        [
          {
            text: 'OK',
            onPress: () => navigation.goBack(),
          },
        ],
        { cancelable: false }
      );
    } catch (e: any) {
      const msg = e?.message || 'Erro ao salvar o projeto.';
      setErrorText(msg);
      Alert.alert('Erro', msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={s.root}>
      <ScrollView contentContainerStyle={s.content}>
        <Card>
          <Field label="Título *">
            <Input
              placeholder="Ex: Toalha de Mesa em Crochê"
              value={title}
              onChangeText={setTitle}
            />
          </Field>

          <Field label="Categoria *">
            <Select
              value={category}
              onChange={setCategory}
              items={CATEGORIES}
              placeholder="Selecione a categoria"
            />
          </Field>

          <Field label="URL de Referência">
            <Input
              placeholder="https://exemplo.com/receita"
              value={refUrl}
              onChangeText={setRefUrl}
              autoCapitalize="none"
            />
          </Field>

          <Field label="Arquivo de Referência (Foto ou PDF)">
            <UploadPicker
              attachment={attachment}
              onPick={pickAttachment}
              onClear={() => setAttachment(null)}
            />
          </Field>
        </Card>

        <Card>
          <Row align="center" style={{ marginBottom: 8 }}>
            <Text style={[s.icon, { color: '#059669' }]}>$</Text>
            <Text style={s.cardTitle}>Orçamento</Text>
          </Row>

          <Row gap={10}>
            <Field small label="Margem %">
              <Input
                value={margin}
                onChangeText={setMargin}
                keyboardType="numeric"
              />
            </Field>
            <Field small label="Horas">
              <Input
                value={hours}
                onChangeText={setHours}
                keyboardType="numeric"
              />
            </Field>
            <Field small label="R$/hora">
              <Input
                value={hourRate}
                onChangeText={setHourRate}
                keyboardType="numeric"
              />
            </Field>
          </Row>

          <BudgetSummary
            mat={totals.mat}
            labor={totals.labor}
            price={totals.price}
          />
        </Card>

        <Card>
          <Text style={s.sectionTitle}>Materiais</Text>

          {materials.map((m) => (
            <MaterialsRow
              key={m.id}
              row={m}
              onChange={updateRow}
              onRemove={removeRow}
            />
          ))}

          <Pressable onPress={addMaterialRow} style={s.addRow}>
            <Text style={s.addRowText}>+ Adicionar material</Text>
          </Pressable>
        </Card>

        <Card>
          <Field label="Passos/Observações">
            <Input
              placeholder="Descreva os passos do projeto ou adicione observações"
              value={notes}
              onChangeText={setNotes}
              multiline
              style={{ height: 100, textAlignVertical: 'top' }}
            />
          </Field>
        </Card>

        <View style={{ height: 28 }} />

        {errorText ? (
          <Text style={{ color: '#DC2626', marginTop: 4 }}>{errorText}</Text>
        ) : null}

        <View style={s.footer}>
          <Pressable
            style={[
              s.saveBtn,
              loading || !canSave ? { opacity: 0.6 } : null,
            ]}
            disabled={loading || !canSave}
            onPress={onSubmit}
          >
            <Text style={s.saveText}>
              {loading
                ? 'Salvando…'
                : isEditing
                ? 'Atualizar Projeto'
                : 'Salvar Projeto'}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

function makeRow(): MaterialRow {
  return { id: nanoid(), name: '', qty: '', unit: 'un', unitCost: '' };
}

function Card({
  children,
}: React.PropsWithChildren & { style?: any }) {
  return <View style={s.card}>{children}</View>;
}

export function Field({
  label,
  children,
  small,
}: React.PropsWithChildren & { label: string; small?: boolean }) {
  return (
    <View style={[s.field, small && { flex: 1 }]}>
      <Text style={s.label}>{label}</Text>
      <View>{children}</View>
    </View>
  );
}

export function Input(props: React.ComponentProps<typeof TextInput>) {
  return (
    <TextInput
      {...props}
      placeholderTextColor={theme.colors.muted}
      style={[s.input, props.style]}
    />
  );
}

export function SumRow({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <Row justify="space-between" style={{ marginBottom: 6 }}>
      <Text style={[s.sumLabel, highlight && s.sumHL]}>{label}</Text>
      <Text style={[s.sumValue, highlight && s.sumHL]}>{value}</Text>
    </Row>
  );
}