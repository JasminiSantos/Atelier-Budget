import { StyleSheet } from 'react-native';
import { theme } from '../../../theme/theme';

export const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.colors.appBg },

  content: { padding: 16, paddingBottom: 32 },

  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowOffset: { width: 0, height: 6 },
    shadowRadius: 12,
    elevation: 2,
  },

  field: { marginBottom: 12 },
  label: { color: theme.colors.text, fontWeight: '600', marginBottom: 6 },

  input: {
    backgroundColor: theme.colors.inputBg,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: theme.colors.border,
    color: theme.colors.text,
    height: 44,
  },

  // orçamento
  icon: { fontSize: 18, marginRight: 6 },
  cardTitle: { fontSize: 16, fontWeight: '700', color: theme.colors.text },

  sumBox: {
    backgroundColor: '#E8F8EE',
    borderRadius: 12,
    padding: 14,
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#C7F0D8',
  },
  sep: { height: 1, backgroundColor: '#B7E8CC', marginVertical: 6 },
  sumLabel: { color: '#374151', fontWeight: '600' },
  sumValue: { color: '#111827', fontWeight: '700' },
  sumHL: { color: '#047857' },

  // seção
  sectionTitle: { fontSize: 16, fontWeight: '700', color: theme.colors.text, marginBottom: 8 },

  // lixeira branca com ícone vermelho
  trashWhite: {
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#FCA5A5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tCenter: { textAlign: 'center' as const },

  // adicionar material
  addRow: {
    marginTop: 6,
    alignSelf: 'flex-start',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: '#F3F4F6',
  },
  addRowText: { color: theme.colors.text, fontWeight: '600' },

  // rodapé
  footer: {
    padding: 12,
    backgroundColor: 'transparent',
  },
  saveBtn: { backgroundColor: theme.colors.primary, borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginBottom: 12 },
  saveText: { color: theme.colors.primaryFg, fontWeight: '700', fontSize: 16 },
});
