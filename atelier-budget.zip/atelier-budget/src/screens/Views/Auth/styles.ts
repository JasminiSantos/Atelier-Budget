import {
  StyleSheet,
} from 'react-native';
import { theme } from '../../../theme/theme';

export const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.colors.appBg },
  center: {
    flex: 1, paddingHorizontal: 18, alignItems: 'center', justifyContent: 'center',
  },
  logoWrap: { alignItems: 'center', marginBottom: 8 },
  logoCircle: {
    width: 56, height: 56, borderRadius: 56, backgroundColor: '#F3EFFF',
    alignItems: 'center', justifyContent: 'center',
  },
  title: { textAlign: 'center', fontSize: 18, fontWeight: '700', color: theme.colors.text, marginTop: 10 },
  subtitle: { textAlign: 'center', color: theme.colors.muted, marginTop: 6, marginBottom: 14 },
  error: { color: '#B91C1C', marginBottom: 8 },
});