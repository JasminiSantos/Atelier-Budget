import React, { useState } from 'react';
import {
  View, Text, KeyboardAvoidingView, Platform, Image, Alert,
} from 'react-native';
import { theme } from '../../../theme/theme';
import AppCard from '../../../components/AppCard';
import SegmentedTabs from '../../../components/SegmentedTabs';
import AppTextInput from '../../../components/AppTextInput';
import AppButton from '../../../components/AppButton';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../../screens/Navigator/Types';
import { styles } from './styles';
import { signIn, signUp } from '../../../services/auth';
import * as Linking from 'expo-linking';

type Props = NativeStackScreenProps<RootStackParamList, 'Auth'>;

export default function AuthScreen({ navigation }: Props) {
  const [tabIndex, setTabIndex] = useState<0 | 1>(0);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  const isSignup = tabIndex === 1;
  const canSubmit =
    /\S+@\S+\.\S+/.test(email) &&
    password.length > 0 &&
    !loading;

  async function onSubmit() {
    setLoading(true);
    setErrorText(null);
    try {
      if (isSignup) {
      const redirectTo = Linking.createURL('/auth/callback');

      const { data, error } = await signUp(email, password, redirectTo);
        if (error) throw error;

        if (!data.session) {
          Alert.alert(
            'Confirme seu e-mail',
            'Enviamos um link para confirmar sua conta. Depois de confirmar, volte e faça login.'
          );
          return;
        }
      } else {
        const { data, error } = await signIn(email, password);
        if (error) throw error;
      }
    } catch (e: any) {
      const msg = String(e?.message || '');
      if (msg.includes('Invalid login credentials')) {
        setErrorText('Credenciais inválidas. Confira e-mail e senha.');
      } else if (msg.includes('User already registered')) {
        setErrorText('Já existe uma conta para este e-mail.');
      } else if (msg.includes('Email rate limit exceeded')) {
        setErrorText('Limite de e-mails excedido. Tente novamente mais tarde.');
      } else if (msg.includes('Passwords do not match')) {
        setErrorText('As senhas não conferem.');
      } else {
        setErrorText('Erro ao autenticar. Tente novamente.');
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.select({ ios: 'padding', android: undefined })}
      style={styles.root}
    >
      <View style={styles.center}>
        <AppCard>
          <View style={styles.logoWrap}>
            <View style={styles.logoCircle}>
            <Image
              source={require('../../../img/palette.png')}
              style={{ width: 28, height: 28, tintColor: theme.colors.accent }}
            />
            </View>
          </View>

          <Text style={styles.title}>Atelier Budget</Text>
          <Text style={styles.subtitle}>Organize qualquer projeto de artesanato em segundos</Text>

          <SegmentedTabs
            items={['Login', 'Cadastro']}
            index={tabIndex}
            onChange={(i) => setTabIndex(i as 0 | 1)}
          />

          <AppTextInput
            label="E-mail"
            placeholder="seu@email.com"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <AppTextInput
            label="Senha"
            placeholder="mín. 6 caracteres"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoCapitalize="none"
          />
          <View style={{ minHeight: 85 }}>
          {isSignup && (
            <AppTextInput
              label="Confirmar senha"
              placeholder="repita a senha"
              value={confirm}
              onChangeText={setConfirm}
              secureTextEntry
              autoCapitalize="none"
            />
          )}
          </View>

          {errorText ? <Text style={styles.error}>{errorText}</Text> : null}

          <AppButton
            title={isSignup ? 'Criar conta' : 'Entrar'}
            onPress={onSubmit}
            loading={loading}
            disabled={!canSubmit}
            testID="auth-submit"
          />
        </AppCard>
      </View>
    </KeyboardAvoidingView>
  );
}
